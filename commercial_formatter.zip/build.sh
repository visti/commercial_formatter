odin build . && sudo cp commercial_formatter /usr/bin/komm_fmt
echo "Saved new build to /usr/bin"
